#include "ktp_structures.h"

#ifndef KGP_TRANSFER_PROTOCOL
#define KGP_TRANSFER_PROTOCOL

int k_socket(int __domain, int __type, int __protocol);
int k_bind(int sockid, struct sockaddr_in * source, struct sockaddr_in * destination);
int k_sendto(int sockid, struct sockaddr_in * destination, char message[]);
int k_recvfrom(int sockid, struct sockaddr_in * destination, char * buff);
void k_close(int sockid);

#endif